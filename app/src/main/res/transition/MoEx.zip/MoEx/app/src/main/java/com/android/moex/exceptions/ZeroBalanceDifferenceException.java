package com.android.moex.exceptions;

public class ZeroBalanceDifferenceException extends Exception{
    public ZeroBalanceDifferenceException(String text) {
        super(text);
    }
}
