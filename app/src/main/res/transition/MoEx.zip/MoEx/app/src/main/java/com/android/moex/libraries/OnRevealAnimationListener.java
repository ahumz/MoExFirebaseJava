package com.android.moex.libraries;

public interface OnRevealAnimationListener {
    void onRevealHide();
    void onRevealShow();
}
