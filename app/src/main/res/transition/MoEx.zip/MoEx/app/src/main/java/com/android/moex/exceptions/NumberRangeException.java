package com.android.moex.exceptions;

public class NumberRangeException extends Exception{
    public NumberRangeException(String text) {
        super(text);
    }
}
